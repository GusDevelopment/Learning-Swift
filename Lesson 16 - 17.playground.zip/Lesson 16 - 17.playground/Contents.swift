import UIKit

//Lesson 16 Arrays
//Arrays
//A collection of data types ordered by indexes

var a = "Dog"
var b = "Cat"
var c = "Bird"

var myArray = ["Dog", "Cat", "Bird"]

//if you need to do something to each item and return it back to the array use this way
//for counter in 0...myArray.count-1 {
//    myArray[counter] = "My " + myArray[counter]
//    print(myArray[counter])
//}

// if all you need is to print every item use this way
for item in myArray {
    print(item)
}

// How to declare an empty array
var emptyArray:[String] = []
var emptyArray2 = [String]()

// Add items
myArray.append("Racoon")
myArray.insert("Frog", at: 0)
myArray += ["Frog", "Bear"]

for item in myArray {
    print(item)
}

// Remove items
myArray.remove(at: 0)


//Search your array
myArray.firstIndex(of: "Bear")


////Exercise
//
//class Pets {
//
//    var name = ""
//
//
//    init() {
//        name = "Ghost"
//    }
//
//    init(_ name:String) {
//        self.name = name
//    }
//
//    func feed() {
//        print("\(name) has been fed")
//    }
//
//    func clean() {
//        print("\(name) has taken a bath")
//    }
//
//    func play() {
//        print("\(name) enjoyed playing with you")
//    }
//
//    func sleep() {
//        print("\(name) went to sleep")
//    }
//
//}
//
//class Tamagotchi: Pets {
//
//    var hunger = 0
//    var dirt = 0
//    var boredom = 0
//    var drowsiness = 0
//
//    // Array is in the following order ["hunger", "dirt", "boredom", "drowsiness"]
//    var properties = [0,0,0,0]
//    var ageInDays:Double = 0
//    var age:Double? {
//       return ageInDays / 30
//    }
//
//    override init() {
//        super.init()
//        properties[2] = 60 //boredom
//        ageInDays = 0
//    }
//
//    convenience override init(_ name:String) {
//        self.init()
//
//        self.name = name
//    }
//
//    override func feed() {
//        if properties[0] == 0 {
//            print("\(name) is already full")
//        } else {
//            super.feed()
//        }
//
//        properties[0] = 0 //hunger
//        properties[1] += 20 //dirt
//        properties[2] += 20 //boredom
//        properties[3] += 10 //drowsiness
//    }
//
//    override func clean() {
//        if properties[1] == 0 {
//            print("\(name) is already clean")
//        } else {
//            super.clean()
//        }
//
//        properties[1] = 0 //dirt
//        properties[2] += 20 //boredom
//        properties[0] += 20 //hunger
//        properties[3] += 10 //drowsiness
//    }
//
//    override func play() {
//        if properties[2] == 0 {
//            print("\(name) is already done")
//        } else {
//            super.play()
//        }
//
//        properties[2] = 0 //boredom
//        properties[1] += 20 //dirt
//        properties[0] += 20 //hunger
//        properties[3] += 10 //drowsiness
//
//    }
//
//    override func sleep() {
//        if properties[3] == 0 {
//            print("\(name) has already slept")
//        } else {
//            super.sleep()
//            ageInDays += 1
//            properties[3] = 0 //drowsiness
//            properties[0] += 20 //hunger
//            properties[2] += 20 //boredom
//            properties[1] += 10 //dirt
//        }
//
//    }
//
//    func check() {
//        print("hunger : \(properties[0])");
//        print("dirt : \(properties[1])");
//        print("boredom : \(properties[2])");
//        print("drowsiness : \(properties[3])");
//
//        if properties[0] >= 60 {
//            print("\(name) is hungry")
//        }
//
//        if properties[1] >= 60 {
//            print("\(name) is dirty")
//        }
//
//        if properties[2] >= 60 {
//            print("\(name) is bored")
//        }
//
//        if properties[3] >= 60 {
//            print("\(name) is sleepy")
//        }
//    }
//
//    func getAge() {
//        print("\(name) is \(age!) months old")
//    }
//}
//
//var game = Tamagotchi()
//game.name = "Bunny"
//
//for _ in 1...15{
//    game.play()
//    game.feed()
//    game.clean()
//    game.sleep()
//    game.check()
//}
//
//game.getAge()


//Lesson 17 Dictionaries

// Declaring an empty string:string dictionary
var myDictionary = [String:String]()


// assigning data into a dictionary
myDictionary["SJD 293"] = "Red Ferrari"
myDictionary["UDS 111"] = "Silver Porsche"

// retriving a value as optional string
let myCar = myDictionary["SJD 293"]

// replacing the value for a key
myDictionary["SJD 293"] = "Black Lambo"

//remove a value for a key
//myDictionary["SJD 293"] = nil

// Loop through the items of a dictionary
for (key, value) in myDictionary {
    // Do stuff for each item of the dictionary
    print("\(key) is a \(value)")
}

//Exercise

class Pets {
    
    var name = ""
    
    
    init() {
        name = "Ghost"
    }
    
    init(_ name:String) {
        self.name = name
    }
    
    func feed() {
        print("\(name) has been fed")
    }
    
    func clean() {
        print("\(name) has taken a bath")
    }
    
    func play() {
        print("\(name) enjoyed playing with you")
    }
    
    func sleep() {
        print("\(name) went to sleep")
    }
    
}

class Tamagotchi: Pets {
    
    var hunger = 0
    var dirt = 0
    var boredom = 0
    var drowsiness = 0
    
    // Array is in the following order ["hunger", "dirt", "boredom", "drowsiness"]
    var properties = [String:Int]()
    var ageInDays:Double = 0
    var age:Double? {
       return ageInDays / 30
    }
    
    override init() {
        super.init()
        properties["hunger"] = 0
        properties["dirt"] = 0
        properties["boredom"] = 60
        properties["drowsiness"] = 0
        ageInDays = 0
    }
    
    convenience override init(_ name:String) {
        self.init()
        
        self.name = name
    }
    
    override func feed() {
        if properties["hunger"] == 0 {
            print("\(name) is already full")
        } else {
            super.feed()
        }
        
        properties["hunger"] = 0;
        properties["dirt"]! += 20;
        properties["boredom"]! += 20;
        properties["drowsiness"]! += 10;
    }
    
    override func clean() {
        if properties["dirt"] == 0 {
            print("\(name) is already clean")
        } else {
            super.clean()
        }
        
        properties["dirt"] = 0
        properties["boredom"]! += 20
        properties["hunger"]! += 20
        properties["drowsiness"]! += 10
    }
    
    override func play() {
        if properties["boredom"] == 0 {
            print("\(name) is already done")
        } else {
            super.play()
        }
        
        properties["boredom"] = 0
        properties["dirt"]! += 20
        properties["hunger"]! += 20
        properties["drowsiness"]! += 10
        
    }
    
    override func sleep() {
        if properties["drowsiness"] == 0 {
            print("\(name) has already slept")
        } else {
            super.sleep()
            ageInDays += 1
            properties["drowsiness"] = 0
            properties["hunger"]! += 20
            properties["boredom"]! += 20
            properties["dirt"]! += 10
        }
        
    }
    
    func check() {
        print("hunger : \(properties["hunger"]!)");
        print("dirt : \(properties["dirt"]!)");
        print("boredom : \(properties["boredom"]!)");
        print("drowsiness : \(properties["drowsiness"]!)");
        
        if properties["hunger"]! >= 60 {
            print("\(name) is hungry")
        }
        
        if properties["dirt"]! >= 60 {
            print("\(name) is dirty")
        }
        
        if properties["boredom"]! >= 60 {
            print("\(name) is bored")
        }
        
        if properties["drowsiness"]! >= 60 {
            print("\(name) is sleepy")
        }
    }
    
    func getAge() {
        print("\(name) is \(age!) months old")
    }
}

var game = Tamagotchi()
game.name = "Bunny"

for _ in 1...15{
    game.play()
    game.feed()
    game.clean()
    game.sleep()
    game.check()
}

game.getAge()
