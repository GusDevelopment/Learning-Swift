import UIKit

//Lesson 13 Optionals

// a can store an Int, but it is wrapped
var a:Int?

// b can store a String, but it is already unwrapped
var b:String!


class XmasPresent {
    func surprise() -> Int {
        return Int.random(in: 1...10)
    }
}

let present:XmasPresent? = XmasPresent()

//check the optional to see if it contains an object

if present != nil {
    // it contains an object
    // call the surprise function
    print(present!.surprise())
}



//Optional Binding

if let actualPresent = present {
    print(actualPresent.surprise())
}


// Optional chaining

present?.surprise()


// Lesson 14 Properties
/*
class Person {
    var name = ""
    
    init(){
        
    }
    
    init(_ name:String) {
        self.name = name
    }
}

class Employee: Person {
    
    var salary = 0
    var role = ""
    
    
    override init(_ name:String) {
        super.init(name)
        
        self.role = "Analyst"
        
    }
    
    func doWork() {
        print("Hi nmy name is \(name) and I am doing work.")
        salary += 1
    }
    
    
}

class Manager : Employee {
    
    var teamSize = 0
    var bonus:Int = 1000
        // This is a computed property
        // When it is accessed, the code in here will run
        // Then we'll return the value
        // return teamSize = 1000
    
    init(_ name:String, _ team:Int) {
        //This calls the init of the Employee Class
        super.init(name)
        
        // Additional init work
        self.teamSize = team
        
    }
    
    override func doWork() {
        super.doWork()
        
        print("I am managing people")
        salary += 2
    }

    func firePeople() {
        print("I am firing people")
    }

}


let m = Manager("Kate", 11)
print(m.bonus)
*/

// Lesson 15 Designated and Convenience Initializers

class Person {
    
    var name:String
    var netWorth:Int?
    var gender:String!
    
    //Designated init because it makes sure that all properties are initialized
    init() {
        name = "none"
    }
    
    //Convenience init
    convenience init(_ gender:String, _ netWorth:Int) {
        //Call the designated init to ensure that the object is ready to go
        self.init()
        
        //Set any other properties or custom code to init for this scenario
        self.gender = gender
        self.netWorth = netWorth
    }
    
}

//Creating a new person obj
let f = Person()
print(f.name)

//Creating a new rich person obj
let g = Person("Male", 100000)
let h = Person("Female", 100000)




//Exercise

class Pets {
    
    var name = ""
    
    
    init() {
        name = "Ghost"
    }
    
    init(_ name:String) {
        self.name = name
    }
    
    func feed() {
        print("\(name) has been fed")
    }
    
    func clean() {
        print("\(name) has taken a bath")
    }
    
    func play() {
        print("\(name) enjoyed playing with you")
    }
    
    func sleep() {
        print("\(name) went to sleep")
    }
    
}

class Tamagotchi: Pets {
    
    var hunger = 0
    var dirt = 0
    var boredom = 0
    var drowsiness = 0
    var ageInDays:Double = 0
    var age:Double? {
       return ageInDays / 30
    }
    
    override init() {
        super.init()
        boredom = 60
        ageInDays = 0
    }
    
    convenience override init(_ name:String) {
        self.init()
        
        self.name = name
    }
    
    override func feed() {
        if hunger == 0 {
            print("\(name) is already full")
        } else {
            super.feed()
        }
        
        hunger = 0
        boredom += 20
        dirt += 20
        drowsiness += 10
    }
    
    override func clean() {
        if dirt == 0 {
            print("\(name) is already clean")
        } else {
            super.clean()
        }
        
        dirt = 0
        hunger += 20
        boredom += 20
        drowsiness += 10
    }
    
    override func play() {
        if boredom == 0 {
            print("\(name) is already done")
        } else {
            super.play()
        }
        
        boredom = 0
        hunger += 20
        dirt += 20
        drowsiness += 10
        
    }
    
    override func sleep() {
        if drowsiness == 0 {
            print("\(name) has already slept")
        } else {
            super.sleep()
            ageInDays += 1
            drowsiness = 0
            boredom += 20
            hunger += 20
            dirt += 10
        }
        
    }
    
    func check() {
        print("\(name) stats are hunger = \(hunger), dirt =  \(dirt), boredom = \(boredom), and drowsiness = \(drowsiness)")
        
        if hunger >= 60 {
            print("\(name) is hungry")
        }
        
        if dirt >= 60 {
            print("\(name) is dirty")
        }
        
        if boredom >= 60 {
            print("\(name) is bored")
        }
        
        if drowsiness >= 60 {
            print("\(name) is sleepy")
        }
    }
    
    func getAge() {
        print("\(name) is \(age!) months old")
    }
}

var game = Tamagotchi()
game.name = "Bunny"

for _ in 1...15{
    game.play()
    game.feed()
    game.clean()
    game.sleep()
    game.check()
}

game.getAge()


