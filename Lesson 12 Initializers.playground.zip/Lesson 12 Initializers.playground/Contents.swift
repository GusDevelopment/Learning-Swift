import UIKit

class Person {
    var name = ""

    init() {
        // custom initinial code
    }
    
    init(_ name:String) {
        self.name = name
    }
    
    
}

class Employee : Person {
    
    var salary = 0
    var role = ""
    
    override init(_ name:String) {
        // this is calling the init func of the person class
        super.init(name)
        
        // this is additional init code
        self.role = "Analyst"
    }
    
    func doWork() {
        print("Hi name is \(name) and I'm doing work")
        salary += 1
    }
}

class Manager : Employee {
    var teamSize = 0
    
    override func doWork() {
        super.doWork()
        
        print("I'm managing people")
        salary += 2
    }
    
    func firingPeople() {
        print("I am firing people")
    }
}

let myPerson = Person()
print(myPerson.name)

let myEmployee = Employee("Tom")
print(myEmployee.role)
print(myEmployee.name)

//Exercise

class Pets {
    
    var name = ""
    var age = 0
    
    init() {
        name = "Ghost"
    }
    
    init(_ name:String) {
        self.name = name
    }
    
    func feed() {
        print("\(name) has been fed")
    }
    
    func clean() {
        print("\(name) has taken a bath")
    }
    
    func play() {
        print("\(name) enjoyed playing with you")
    }
    
    func sleep() {
        print("\(name) went to sleep")
    }
    
}

class Tamagotchi: Pets {
    
    var hunger = 0
    var dirt = 0
    var boredom = 0
    var drowsiness = 0
    
    override init() {
        super.init()
        boredom = 60
    }
    
    override init(_ name:String) {
        super.init(name)
        boredom = 60
    }
    
    override func feed() {
        if hunger == 0 {
            print("\(name) is already full")
        } else {
            super.feed()
        }
        
        hunger = 0
        boredom += 20
        dirt += 20
        drowsiness += 10
    }
    
    override func clean() {
        if dirt == 0 {
            print("\(name) is already clean")
        } else {
            super.clean()
        }
        
        dirt = 0
        hunger += 20
        boredom += 20
        drowsiness += 10
    }
    
    override func play() {
        if boredom == 0 {
            print("\(name) is already done")
        } else {
            super.play()
        }
        
        boredom = 0
        hunger += 20
        dirt += 20
        drowsiness += 10
        
    }
    
    override func sleep() {
        if drowsiness == 0 {
            print("\(name) has already slept")
        } else {
            super.sleep()
        }
        
        
        drowsiness = 0
        boredom += 20
        hunger += 20
        dirt += 10
        
    }
    
    func check() {
        print("\(name) stats are hunger = \(hunger), dirt =  \(dirt), boredom = \(boredom), and drowsiness = \(drowsiness)")
        
        if hunger >= 60 {
            print("\(name) is hungry")
        }
        
        if dirt >= 60 {
            print("\(name) is dirty")
        }
        
        if boredom >= 60 {
            print("\(name) is bored")
        }
        
        if drowsiness >= 60 {
            print("\(name) is sleepy")
        }
    }
}

let myPet = Pets("Tommy")
print(myPet.name)

let game = Tamagotchi("Alpha")
game.clean()
game.check()
game.play()
game.check()
game.feed()
game.check()
game.feed()
game.check()
game.clean()
game.check()
game.play()
game.check()
game.sleep()
game.check()
game.feed()
game.check()



