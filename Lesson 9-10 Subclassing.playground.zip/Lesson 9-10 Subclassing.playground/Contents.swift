import UIKit

class Employee {
    var name = ""
    var salary = 0
    var role = ""
    
    func doWork(){
        print("Hi my name is \(name) and I am doing work.")
        salary += 1
    }
}

class Manager: Employee {
    
    var teamSize = 0
    
    override func doWork() {
        super.doWork()
        
        print("I'm managing people")
        salary += 2
    }
    
    func firePeople(){
        print("I am firing people")
    }
    
}

var m = Manager()
m.name = "Maggie"
m.role = "Manager of IT"
m.salary = 2000
m.teamSize = 10
m.doWork()
m.firePeople()

var e = Employee()



// Exercise

class Pets {
    
    var name = ""
    var age = 0
    
    func feed() {
        print("\(name) has been fed")
    }
    
    func clean() {
        print("\(name) has taken a bath")
    }
    
    func play() {
        print("\(name) enjoyed playing with you")
    }
    
    func sleep() {
        print("\(name) went to sleep")
    }
    
}

class Tamagotchi: Pets {
    
    var hunger = 0
    var dirt = 0
    var boredom = 0
    var drowsiness = 0
    
    override func feed() {
        super.feed()
        
        hunger = 0
        boredom += 20
        dirt += 20
        drowsiness += 10
    }
    
    override func clean() {
        super.clean()
        
        dirt = 0
        hunger += 20
        boredom += 20
        drowsiness += 10
    }
    
    override func play() {
        super.play()
        
        boredom = 0
        hunger += 20
        dirt += 20
        drowsiness += 10
        
    }
    
    override func sleep() {
        
        drowsiness = 0
        boredom += 20
        hunger += 20
        dirt += 10
        
    }
    
    func check() {
        print("\(name) stats are hunger = \(hunger), dirt =  \(dirt), boredom = \(boredom), and drowsiness = \(drowsiness)")
    }
}

var game = Tamagotchi()
game.name = "Ghost"

game.boredom
game.check()
game.clean()
game.check()
game.feed()
game.check()
game.play()
game.check()
