import UIKit

var str = "Hello, playground"

//var firstName = "Gus"
//print(firstName)

var stockPrice = 100
print(stockPrice)

stockPrice = 50
print(stockPrice)

//let lastName = "Espinoza"


let a = 5

if a <= 10{
    print("a is less than 10")
}
else if a < 15 {
    print("a is less than 15")
}

let chr = "c"

if chr == "a"{
    print("the character is a")
}

switch chr {
case "a":
    print("this is an a")
case "b":
    print("this is a b")
default:
    print("this is the fall back")
}


//Lesson Number 3 IS Statements

var lastName = "Espinoza"
var firstName = "Gustavo"
let gender = "Male"
var age:Int = 26
var cashOnHand:Double = 1000.00
var hasChildren:Bool = false

if hasChildren == true {
    print("Being a parent is hard, my money goes to my children instead of games!")
}else if age >= 18 {
    print("Adulting is hard I cant buy the game because I need to pay bills")
}else {
    print("im young and i can do what i want so gimme that game")
}

// Lesson 4 Switch Statements

var strOperator = "*"
var num1 = 7
var num2 = 10
var result:Int

switch strOperator {
case "+":
        print(strOperator)
case "-":
        print(strOperator)
case "*","x":
        print(strOperator)
case "/":
        print(strOperator)
case "^":
        print(strOperator)
default:
    print("this operator doesnt exist")
}



// Lesson 5 Loops

for counter in 1...5{
    print("Hello")
}

var drawPixel = "*"
var height = 10
var tempRow = ""

for columnPixel in 1...height{
    tempRow = ""
    for _ in 1...columnPixel{
        tempRow += drawPixel
    }
    print(tempRow)
}


// Lesson 6 Loops Part 2

var counter = 5

while counter > 0 {
    print("Hello from while loop")
    counter -= 1
}

var runningCash:Double = 0
var percentGain:Double = 5
var yearsToInvest:Int = 10
var yearsElapsed:Int = 0

runningCash = cashOnHand
percentGain = percentGain/100

repeat{
    runningCash = runningCash + (runningCash * percentGain)
    print(runningCash)
    yearsElapsed += 1
} while yearsElapsed < yearsToInvest


//Lesson 7 Functions

/*
 
 func addTwoNumber(){
    let a = 1
    let b = 2
    let c = a + b

    print(c)
}

*/


func subtractTwoNumbers(){
    let d = 5
    let e = 1
    let f = d - e
    
    print(f)
}

func walkNorth(){
    print("You walked North.")
}

func walkSouth(){
    print("You walked South.")
}

func walkEast(){
    print("You walked East.")
}

func walkWest(){
    print("You walked West.")
}

walkNorth()
walkSouth()
walkEast()
walkWest()


//Lesson 8 Functions Part 2

/*
 func addTwoNumber() -> Int {
    let a = 1
    let b = 2
    let c = a + b

    return(c)
}

let sum = addTwoNumber()
print(sum)
*/

func addTwoNumber(number1:Int, number2:Int) -> Int {
    let a = number1
    let b = number2
    let c = a + b

    return(c)
}

let sum = addTwoNumber(number1: 5, number2: 3)
print(sum)

func walk(_ direction:String,_ steps:Int) -> String {
    return("You have walked " + String(steps) + " steps to the " + direction)
}

var resultStr = walk("North", 5)
print(resultStr)


// Lesson 9 Classes

class Employee {
    //Properties of the class
    var name = ""
    var role = ""
    var salary = 0
    
    
    // Methods of the class
    func doWork() {
        print("Hi my name is \(name) and I am doing work.")
        salary += 1
    }
}

let c:Employee = Employee()

c.name = "Tom"
c.role = "Art Director"
c.salary = 1000
print(c.name)



class Pets {
    var name = ""
    var age = 0

    func feed() {
        print("\(name) had been fed.")
    }
    
    func clean() {
        print("\(name) has taken a bath.")
    }
    
    func play() {
        print("\(name) has enjoyed playing with you.")
    }
    
    func sleep() {
        print("\(name) went to sleep.")
    }
    
}


var pet:Pets = Pets()

pet.age = 5
pet.name = "Ghost"

pet.clean()
pet.feed()
pet.play()
pet.sleep()


